/*
** Copyright (C) 2008 José Vander Meulen <jose.vandermeulen@uclouvain.be>, 
**                    Charles Pecheur <charles.pecheur@uclouvain.be>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/


/*
** LSINF2224 - Programming methods
** 2012 - 2013
** Assignment 1
** Antoine Maes
** SINF21MS/G
** 08/03/2013
*/

public class PatternMatching {

    /**
     * Returns true iff p occurs as a substring in t starting at index k.
     */
    /*@@
      @ requires p != null && t != null;
      @ requires 0 <= k;
      @ requires k + p.length <= t.length;
      @ ensures \result <==> (\forall int i; 0 <= i && i < p.length;
      @                             p[i] == t[k+i]);
      @ also
      @ requires p != null && t != null;
      @ requires 0 <= k;
      @ requires k + p.length > t.length;
      @ ensures ! \result;
      @*/
    private static boolean matches(int[] p, int[] t,  int k) {
        boolean result;
        if (k + p.length > t.length) {
            result = false;
        } else {
            int i = 0;
            boolean match = true;
            /*@ loop_invariant 0 <= i && i <= p.length;
              @ loop_invariant match <==> (\forall int j; 0 <= j &&
              @                             j < i; p[j] == t[k+j]);
              @ decreasing p.length - i;
              @*/
            while (i != p.length && match) {
                match = p[i] == t[k + i];
                i = i + 1;
            }
            result = match;
        }
        return result;
    }

    /**
     * 	Returns the smallest index i such that p is a substring of
	 * t starting at i.  Returns a negative number if p is not
	 * a substring of t.
     */
    /*@@
      @ requires p != null && t != null;
      @ requires p.length != 0;
      @ requires (\exists int i; 0 <= i && i < t.length;
      @                                         matches (p, t, i));
      @ ensures \result >= 0;
      @ //ensures matches (p, t, \result);
      @ //ensures (\forall int i; 0 <= i && i < \result;
      @                                         !matches (p, t, i));
      @ also
      @ requires p != null && t != null;
      @ requires p.length != 0;
      @ requires (\forall int i; 0 <= i && i < t.length;
      @                                         !matches (p, t, i));
      @ //ensures \result < 0;
      @*/
    public static int find(int[] p, int[] t) {
        int i = 0;
        /*@ loop_invariant i >= 0;
          @ loop_invariant (\exists int j; 0 <= j && j <= i;
          @         matches (p, t, j)) ==> matches (p, t, i);
          @ loop_invariant (\forall int j; 0 <= j && j < i;
          @                     !matches(p, t, j));
          @ decreasing t.length - i;
          @*/
        while (i <= t.length - p.length) {
            if (matches(p, t, i)) {
                return i;
            }
            i = i + 1;
        }
        return -1;
    }

    public static int find(int[] p, int[] t, int n) {
        int i = n;
        int result = -1;
        while (i <= t.length - p.length && result < 0) {
            if (matches(p, t, i)) {
                result = i;
            }
            i = i + 1;
        }
        return result;
    }

    /*@
      @ requires p != null && t != null;
      @*/
    public static int findLast(int[] p, int[] t) {
        int last = -1;
        int tmp;
        do {
            tmp = find(p, t, last + 1);
            if(tmp >= 0) {
                last = tmp;
            }
        } while(tmp >= 0);
    }
}
