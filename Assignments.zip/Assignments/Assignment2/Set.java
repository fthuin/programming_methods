/**
 * SINF2224 - Programming methods
 * Academic year 2012-2013
 * Assignment 2
 * Antoine Maes
 * SINF21MS/G
 * 19/04/2013
 */

/**
 * A bounded priority queue (of integers) with no duplicate element, 
 * implemented as an ordered array where elements are kept sorted.
 */
public class Set {

    private /*@ non_null*/ int[] data;    // the elements of the queue
    private  int size;      // the number of elements in the queue


    /*@@
      @ // The size of the set cannot be more than the maximum size
      @ invariant 0 <= size && size <= data.length;
      @ // The set is ordered
      @ invariant (\forall int i, j; 0 <= i && i < j && j < size;
      @                              data[i] <= data[j]);
      @
      @ invariant data.owner == this;
      @*/

    /**
     * Return an empty set with a capacity of max elements (max >= 0).
     */
    /*@@
      @ requires max >= 0;
      @
      @ ensures size == 0;
      @ ensures data.length == max;
      @*/
    public Set(int max) {
        data = new int[max];
        //@ set data.owner = this;
        size = 0;
    }

    /**
     * Return the size of the set.
     */
    /*@@    
      @ ensures \result == size;
      @*/
    public /*@ pure */ int size() {
        return size;
    }

    /**
     * Return element at index {n}.
     */
    /*@@
      @ requires 0 <= n && n < size;
      @
      @ ensures \result == data[n];
      @*/
    public /*@ pure */ int get(int n) {
        return data[n];
    }

    /**
     * Add {n} in the set.  Returns the index where {n} was inserted.
     */
    /*@@
      @ // Case where the set doesn't contain n
      @ requires size < data.length;
      @ requires !contains(n);
      @
      @ modifies size, data[*];
      @
      @ ensures size == \old(size) + 1;
      @ ensures 0 <= \result && \result < size;
      @ ensures data[\result] == n;
      @
      @ // All elements smaller than n have not moved
      @ ensures (\forall int i; 0 <= i && i < \result; get(i)
      @                                         == \old(data[i]));
      @
      @ // All elements higher than n have moved one index up
      @ ensures (\forall int i; \result < i && i < size; get(i)
      @                                         == \old(data[i-1]));
      @
      @ // n is at the right place
      @ ensures (\forall int i; 0 <= i && i < \result; get(i) <= n);
      @ ensures (\forall int i; \result < i && i < size;
      @                                                 get(i) >= n);
      @
      @     also
      @
      @ // Case where the set already contains n
      @ requires size < data.length;
      @ requires contains(n);
      @
      @ modifies \nothing;
      @
      @ ensures 0 <= \result && \result < size;
      @ ensures data[\result] == n;
      @*/
    public int enqueue(int n) {
        int i = indexOf(n);
        
        if(i == size || data[i] != n) {
            // shift elements one index up, from size-1 down to i.
            int j = size;
            while (j > i) {
                data[j] = data[j-1];
                j = j - 1;
            }

            data[i] = n;
            size = size + 1;
        }
        return i;
    }


    /**
     * Remove and return highest (i.e. last) element in the set.
     */
    /*@@
      @ requires size > 0;
      @
      @ modifies size;
      @
      @ ensures size == \old(size) - 1;
      @ ensures \result == \old(data[size-1]);
      @*/
    public int dequeue() {
        size = size - 1;
        return data[size];
    }

    /**
     * Returns the index of the first element greater or equal to {n} in the set.  
     * Returns the size of the set if all elements are smaller than {n}.
     */
    /*@@
      @ ensures 0 <= \result && \result <= size;
      @
      @ // All elements with index smaller than the result are 
      @ // smaller than n
      @ ensures (\forall int i; 0 <= i && i < \result; get(i) < n);
      @
      @ // All elements with index greater than the result are
      @ // greater than n
      @ ensures (\forall int i; \result <= i && i < size; 
      @                                             get(i) >= n);
      @*/
    public /*@ pure*/ int indexOf(int n) {
        int i = 0;
        while (i < size && data[i] < n) {
            i = i + 1;
        }
        return i;
    }

    /**
     * Returns {true} iff {n} is in the set.  
     */
    /*@@
      @ ensures \result <==> (\exists int i; 0 <= i && i < size; 
      @                                                 get(i) == n);
      @*/
    public /*@ pure */ boolean contains(int n) {
        int i = indexOf(n);
        return (i < size && data[i] == n);
    }

}
